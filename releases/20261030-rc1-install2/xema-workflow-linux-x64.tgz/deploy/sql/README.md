# Manual Inbound CDR Report

`inbound-cdr-south-manual.sql` registers the operator-supplied original SOUTH
Inbound CDR report. It reads `SimpleCdr.Calls`, not `SimpleCdrWorker.Calls`.
The installer ships this file but never runs it automatically.

Before use, back up `Xema.Reports`, inspect `Xema.ReportGroups`, and set the
script's `@ReportGroupId` and `@InitialPermissions` for that site. Run manually
in an authenticated MariaDB/MySQL client:

```sql
SELECT Id, Name FROM Xema.ReportGroups;
SOURCE /path/to/package/deploy/sql/inbound-cdr-south-manual.sql;
```

The existing query, inclusive FromEpoch/exclusive ToEpoch conditions, column
order and aliases are retained. `HoldTime` appears as `ansholdtime`; `TalkTime`
as `AgentDuration`; `AgentTime` as `TotalTimeAtAgent`. The script calculates no
durations and changes no call rows, datasets, dialers or recordings.

Sequential reruns do not create another report. An existing description is
left untouched, including its owner/access, query and columns. This is not a
concurrent migration or an update utility. Review existing reports manually;
do not rerun the original unguarded INSERT to repair one.

`Role:Manager;` is the supplied default, not a universal access policy. Set the
owner/permissions in Admin for each installation as required. A successful
registration is not call-flow, clean-install or production qualification.
