-- Manual report registration only. Never executed automatically by the installer.
-- Preserves the supplied SOUTH report query, column order, names and calculations.
-- Existing reports and all CDR/campaign/recording data are left untouched.
-- Set these two values for the installed site before running the file.
SET @ReportGroupId = 2;
SET @InitialPermissions = 'Role:Manager;';

SET @LegacyInboundQuery = '
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED ;
SELECT
*
FROM SimpleCdr.Calls
WHERE
CallId >= ''{FromEpoch}'' AND
CallId < ''{ToEpoch}'' AND
`InOut` = ''In''
; COMMIT ;
';

SET @LegacyInboundColumns = 'Date:;OriginNumber:CLI;text10:Location;CallId:CUCID;ChannelId:AUCID;text4:Application;int1:Hour;IvrStartTimestamp:IVRStartTime;IvrEndTimestamp:IVREndTime;IvrTime:IVRDuration;text6:IvrBillingCategory;text2:QueVDN;text8:Level;QueueTime:QueDuration;QueueStartTimestamp:QueStartTime;QueueEndTimestamp:QueEndTime;AgentId:AgentID;AgentStartTimestamp:AgentStartTime;AgentEndTimestamp:AgentEndTime;EndTimestamp:CallEndTime;TalkTime:AgentDuration;HoldTime:ansholdtime;AgentTime:TotalTimeAtAgent;text7:AgentBillingCategory;ConnectedTime:TotalDuration;longtext1:Traversal;int2:FRL;int4:CallReleaseStatus;RingTime:;text9:DelayTime;WrapTime:WorkTime;Recorded:;text1:IVRdissatisfaction;PhoneId:;DialerId:;';

INSERT INTO Xema.Reports (
    Name, Description, ReportGroupId, Permissions, Template, MenuDisplayOrder,
    Prefetch, FilterOptions, QueryText, WhereCondition, ColumnAltNames
)
SELECT 'Cdr', 'Download Inbound Cdr', @ReportGroupId, @InitialPermissions,
       'cdr', 0, 0, NULL, @LegacyInboundQuery, '', @LegacyInboundColumns
WHERE EXISTS (SELECT 1 FROM Xema.ReportGroups WHERE Id = @ReportGroupId)
  AND NOT EXISTS (SELECT 1 FROM Xema.Reports WHERE Description = 'Download Inbound Cdr');

SET @CreatedReportRows = ROW_COUNT();
SELECT @CreatedReportRows AS CreatedReportRows,
       CASE WHEN @CreatedReportRows = 1 THEN 'Created: original SOUTH inbound CDR configuration'
            ELSE 'Not created: check selected group or an existing report; existing settings untouched'
       END AS Result;
SELECT Id, Name, Description, ReportGroupId, Permissions, QueryText, ColumnAltNames
FROM Xema.Reports WHERE Description = 'Download Inbound Cdr';
