#!/usr/bin/env python3
"""Approved generated-staging repair only; never replace site data or credentials."""
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('xema_base', HERE / 'configure-xema-base.py')
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
ROOT = Path('/var/lib/xema')


def require_idle():
    counts = subprocess.check_output(['asterisk', '-rx', 'core show channels count'], text=True).splitlines()
    channels = subprocess.check_output(['asterisk', '-rx', 'core show channels concise'], text=True).strip()
    if '0 active channels' not in counts or '0 active calls' not in counts or channels:
        raise RuntimeError('Active calls or failed call check; repair deferred.')


def sql(query):
    return subprocess.check_output(['mariadb', '-N', '-B'], input=query, text=True)


def ava_plan(data, secret):
    result = copy.deepcopy(data)
    keys = [key for key in result if key.casefold() == 'ari']
    if len(keys) != 1:
        raise ValueError('Exactly one Ava Ari section required.')
    key = keys[0]
    if result[key].get('Host') not in ('localhost', '127.0.0.1') or result[key].get('Port') != 8088:
        raise ValueError('Non-default ARI endpoint requires separate site review.')
    patch = base.component_options({key: result[key]}, secret)
    result[key] = patch[key]
    return result


def validate_worker_schemas(simple, sipper):
    if simple.get('SimpleCdrDatabase', {}).get('DatabaseName') != 'SimpleCdrWorker':
        raise ValueError('SimpleCdr must retain its separate worker schema.')
    if sipper.get('SipperDatabase', {}).get('DatabaseName') != 'Sipper':
        raise ValueError('Unexpected Sipper schema; review before granting access.')


def historical_calls(boundary):
    if not re.fullmatch('[0-9A-F]+', boundary):
        raise ValueError('Invalid historical-call boundary.')
    return subprocess.check_output(['mariadb-dump', '--single-transaction', '--skip-lock-tables',
                                    '--skip-comments', '--compact', '--order-by-primary',
                                    '--skip-extended-insert', 'SimpleCdr', 'Calls',
                                    "--where=CallId <= X'" + boundary + "'"])


def main():
    if sys.argv[1:] != ['--apply-approved-staging'] or os.geteuid() != 0:
        raise RuntimeError('Root and explicit --apply-approved-staging flag required.')
    addresses = json.loads(subprocess.check_output(['ip', '-j', '-4', 'addr'], text=True))
    if not any(a.get('local') == '192.168.252.131' for item in addresses for a in item.get('addr_info', [])):
        raise RuntimeError('Restricted to approved staging; never run on production.')
    secret = json.loads(base.SECRETS.read_text())
    manager = json.loads((ROOT / 'manager/appsettings.json').read_text())
    if (manager['System'].get('AgentPortal') != 'https://192.168.252.131' or
            manager['MariaDb'].get('UserName') != 'xema' or
            manager['MariaDb'].get('Password') != secret['sql'] or
            manager['Asterisk'].get('UserName') != 'xema' or
            manager['Asterisk'].get('Password') != secret['asterisk']):
        raise RuntimeError('Not the generated staging credentials; no changes made.')
    simple = json.loads((ROOT / 'simplecdr/appsettings.json').read_text())
    sipper = json.loads((ROOT / 'sipper/appsettings.json').read_text())
    validate_worker_schemas(simple, sipper)
    scripts = sql("SELECT COUNT(*) FROM Xema.Settings WHERE `Group`='SimpleCdr-PostProcessing' "
                  "AND Name='SqlScript' AND LENGTH(TRIM(COALESCE(ValueString,'')))>0;").strip()
    if scripts != '0':
        raise RuntimeError('Custom CDR post-processing requires review before enabling the worker.')
    ava = ROOT / 'ava/appsettings.json'
    if ava.is_symlink():
        raise RuntimeError('Symlinked Ava configuration requires review.')
    data = json.loads(ava.read_text())
    updated = ava_plan(data, secret)
    require_idle()
    os.umask(0o077)
    backup = Path('/root') / time.strftime('xema-worker-prereqs-%Y%m%d-%H%M%S', time.gmtime())
    backup.mkdir(mode=0o700)
    shutil.copy2(ava, backup / 'ava-appsettings.json')
    (backup / 'grants-before.sql').write_text(sql("SHOW GRANTS FOR 'xema'@'localhost';"))
    boundary = sql('SELECT COALESCE(HEX(MAX(CallId)),\'\') FROM SimpleCdr.Calls;').strip()
    before = historical_calls(boundary) if boundary else b''
    (backup / 'historical-calls.sql').write_bytes(before)
    paths = [ROOT / 'manager' / name for name in ('Manager.dll', 'DbV2.dll', 'Manager.deps.json',
             'appsettings.json', 'wwwroot/agent/index.html', 'wwwroot/live-view/index.html',
             'wwwroot/admin/index.html', 'wwwroot/data-portal/index.html')]
    paths += [Path('/etc/asterisk') / name for name in ('pjsip.conf', 'ari.conf', 'manager.conf', 'extensions.conf')]
    paths += [ROOT / name / (assembly + '.dll') for name, assembly in
              (('simplecdr', 'SimpleCdr'), ('ava', 'Ava'), ('sipper', 'Sipper'))]
    preserved = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths}
    (backup / 'preserved.json').write_text(json.dumps(preserved, indent=2))
    (backup / 'schema-before.txt').write_text(sql("SELECT SCHEMA_NAME FROM information_schema.SCHEMATA "
                                               "WHERE SCHEMA_NAME IN ('SimpleCdrWorker','Sipper');"))
    require_idle()
    # Add only the two reviewed schema grants. Never rerun fresh accounts/rotate credentials.
    sql(base.database_grants(base.WORKER_DATABASES))
    if updated != data:
        require_idle()
        try:
            ava.write_text(json.dumps(updated, indent=2) + '\n')
            subprocess.run(['systemctl', 'restart', 'xema-ava'], check=True)
        except Exception:
            shutil.copy2(backup / 'ava-appsettings.json', ava)
            require_idle()
            subprocess.run(['systemctl', 'restart', 'xema-ava'], check=True)
            raise
    # Sipper migrates its own schema at startup. SimpleCdr retries initialization itself.
    require_idle()
    subprocess.run(['systemctl', 'restart', 'xema-sipper'], check=True)
    time.sleep(10)
    for unit in ('xema-simplecdr', 'xema-ava', 'xema-sipper'):
        subprocess.run(['systemctl', 'is-active', '--quiet', unit], check=True)
    for path, digest in preserved.items():
        if hashlib.sha256(Path(path).read_bytes()).hexdigest() != digest:
            raise RuntimeError('Unexpected preserved-file change: ' + path)
    after = historical_calls(boundary) if boundary else b''
    if before != after:
        raise RuntimeError('Historical CDR verification failed. No automatic SQL restore/drop will be attempted.')
    (backup / 'verified.json').write_text(json.dumps({'historicalBoundaryHex': boundary,
        'historicalSha256': hashlib.sha256(before).hexdigest(), 'verifiedAtEpoch': time.time()}, indent=2))
    print('PASS scoped worker prerequisites applied; historical CDR and Manager/SIP/portal bytes unchanged.')
    print('Backup: ' + str(backup))
    print('Only Ava/Sipper restarted. Additive schemas/grants are retained on failure; never drop/restore data automatically.')


if __name__ == '__main__':
    main()
