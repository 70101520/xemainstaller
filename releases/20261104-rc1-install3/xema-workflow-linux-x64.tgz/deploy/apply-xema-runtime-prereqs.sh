#!/usr/bin/env bash
set -euo pipefail

if [ "$(id -u)" -ne 0 ]; then
  echo "Run as root: sudo $0" >&2
  exit 1
fi
case "$#:${1:-}" in
  0:|1:--asterisk-access-only) ;;
  *) echo "Usage: sudo $0 [--asterisk-access-only]" >&2; exit 2 ;;
esac

timestamp="$(date +%Y%m%d-%H%M%S)"
script_dir="$(cd -- "$(dirname -- "$0")" && pwd)"

backup_file() {
  local path="$1"
  if [ -e "$path" ] && [ ! -e "${path}.xema-bak-${timestamp}" ]; then
    cp -a "$path" "${path}.xema-bak-${timestamp}"
  fi
}

group_exists() {
  getent group "$1" >/dev/null 2>&1
}

ensure_asterisk_config_access() {
  local directory="${1:-/etc/asterisk}" file
  [ -d "$directory" ] || return 0
  [ ! -L "$directory" ] || { echo 'Review symlinked Asterisk configuration directory first.' >&2; return 1; }
  group_exists asterisk || { echo 'Asterisk service group missing.' >&2; return 1; }

  # Manager creates files as root with UMask=0027. Inherit the PBX group, not root.
  chgrp asterisk "$directory"
  chmod g+rx,g+s "$directory"
  for file in "$directory"/*.conf; do
    [ -f "$file" ] && [ ! -L "$file" ] || continue
    case "${file##*/}" in
      flow_[0-9]*.conf|extensions.conf|pjsip.conf|pjsip_wizard.conf|manager.conf|ari.conf|http.conf|modules.conf|queues.conf|cdr.conf|cdr_manager.conf|cel.conf|sip.conf|asterisk.conf|musiconhold.conf)
        if [ "$(stat -c '%G:%a' "$file")" != 'asterisk:640' ]; then
          backup_file "$file"
          chgrp asterisk "$file"
          chmod 0640 "$file"
        fi
        ;;
    esac
  done
}

ensure_asterisk_media_access() {
  local directory path mode
  local roots=("$@")
  if [ "${#roots[@]}" -eq 0 ]; then roots=(/usr/share/asterisk/sounds /usr/share/asterisk/moh); fi
  for directory in "${roots[@]}"; do
    [ -d "$directory" ] || continue
    group_exists asterisk || { echo 'Asterisk service group missing.' >&2; return 1; }
    directory="$(realpath "$directory")"
    # Do not follow nested symlinks or change audio contents/owner identities.
    while IFS= read -r -d '' path; do
      chgrp asterisk "$path"
      chmod g+rx,g+s "$path"
    done < <(find "$directory" -type d -print0)
    while IFS= read -r -d '' path; do
      mode="$(stat -c '%a' "$path")"
      if (( (8#$mode & 4) == 0 )); then
        if [ "$(stat -c '%G' "$path")" != asterisk ] || (( (8#$mode & 32) == 0 )); then
          backup_file "$path"
          chgrp asterisk "$path"
          chmod g+r "$path"
        fi
      fi
    done < <(find "$directory" -type f \( -iname '*.wav' -o -iname '*.gsm' -o -iname '*.sln' -o -iname '*.sln16' -o -iname '*.ulaw' -o -iname '*.alaw' -o -iname '*.g722' -o -iname '*.mp3' -o -iname '*.ogg' -o -iname '*.wav49' \) -print0)
  done
}

ensure_certificates() {
  # Security setup validates the actual server IP/hostname, rather than reusing a stale certificate.
  bash "$script_dir/apply-xema-web-security.sh"
  mkdir -p /etc/ssl/certs /etc/ssl/private /etc/asterisk/keys

  install -m 0644 /etc/ssl/certs/certificate.pem /etc/asterisk/keys/xema-cert.pem
  install -m 0640 /etc/ssl/private/key.pem /etc/asterisk/keys/xema-key.pem

  if group_exists asterisk; then
    chgrp asterisk /etc/ssl/private/key.pem /etc/asterisk/keys/xema-key.pem || true
  fi

  chmod 0644 /etc/ssl/certs/certificate.pem /etc/asterisk/keys/xema-cert.pem
  chmod 0640 /etc/ssl/private/key.pem /etc/asterisk/keys/xema-key.pem
}

ensure_asterisk_http_tls() {
  local file="/etc/asterisk/http.conf"
  [ -f "$file" ] || return 0

  backup_file "$file"

  if ! grep -q '^\[general\]' "$file"; then
    sed -i '1i[general]' "$file"
  fi

  set_http_conf() {
    local key="$1"
    local value="$2"

    if grep -qE "^${key}[[:space:]]*=" "$file"; then
      sed -i "s|^${key}[[:space:]]*=.*|${key}=${value}|" "$file"
    else
      printf '%s=%s\n' "$key" "$value" >> "$file"
    fi
  }

  set_http_conf "bindaddr" "127.0.0.1"
  set_http_conf "enabled" "yes"
  set_http_conf "bindport" "8088"
  set_http_conf "tlsenable" "yes"
  set_http_conf "tlsbindaddr" "0.0.0.0:8089"
  set_http_conf "tlscertfile" "/etc/asterisk/keys/xema-cert.pem"
  set_http_conf "tlsprivatekey" "/etc/asterisk/keys/xema-key.pem"
}

ensure_asterisk_modules() {
  local file="${1:-/etc/asterisk/modules.conf}"
  [ -f "$file" ] || return 0

  local tmp legacy_sip=0
  # Explicit site opt-in is required; fresh PJSIP installs still disable chan_sip.
  if grep -Eq '^[[:space:]]*(load|preload|require)[[:space:]]*=>[[:space:]]*chan_sip\.so[[:space:]]*(;.*)?$' "$file"; then
    if grep -Eq '^[[:space:]]*noload[[:space:]]*=>[[:space:]]*chan_sip\.so[[:space:]]*(;.*)?$' "$file"; then
      echo 'Conflicting chan_sip load/noload directives; review the site module policy first.' >&2
      return 1
    fi
    legacy_sip=1
  fi
  tmp="$(mktemp)"

  awk -v legacy_sip="$legacy_sip" '
    BEGIN { inserted = 0 }
    /^[[:space:]]*(noload[[:space:]]*=>[[:space:]]*chan_sip\.so|load[[:space:]]*=>[[:space:]]*res_http_websocket\.so|load[[:space:]]*=>[[:space:]]*res_pjsip_transport_websocket\.so|load[[:space:]]*=>[[:space:]]*res_pjsip_config_wizard\.so)[[:space:]]*(;.*)?$/ {
      next
    }
    {
      print
      if (!inserted && $0 ~ /^[[:space:]]*autoload[[:space:]]*=[[:space:]]*yes[[:space:]]*$/) {
        if (!legacy_sip) print "noload => chan_sip.so"
        print "load => res_pjsip_config_wizard.so"
        print "load => res_http_websocket.so"
        print "load => res_pjsip_transport_websocket.so"
        inserted = 1
      }
    }
    END {
      if (!inserted) {
        if (!legacy_sip) print "noload => chan_sip.so"
        print "load => res_pjsip_config_wizard.so"
        print "load => res_http_websocket.so"
        print "load => res_pjsip_transport_websocket.so"
      }
    }
  ' "$file" > "$tmp"

  if ! cmp -s "$tmp" "$file"; then
    backup_file "$file"
    cat "$tmp" > "$file"
  fi
  rm -f "$tmp"
}

ensure_pjsip_transport_binds() {
  local file="${1:-/etc/asterisk/pjsip.conf}"
  [ -f "$file" ] || return 0
  local tmp
  tmp="$(mktemp)"

  # Never replace an existing interface/port or NAT setting on a working site.
  # Missing fresh-install binds listen on all interfaces, with access controlled by UFW.
  awk '
    function flush_section() {
      if (section ~ /^transport-(udp|tcp|wss)$/) {
        for (i = 1; i <= count; i++) {
          if (lines[i] ~ /^[[:space:]]*bind[[:space:]]*=/) {
            has_bind = 1
          }
        }
        if (!has_bind) {
          count++
          lines[count] = "bind=0.0.0.0"
        }
      }

      for (i = 1; i <= count; i++) {
        print lines[i]
      }

      count = 0
      section = ""
      has_bind = 0
    }

    /^[[:space:]]*\[[^]]+\]/ {
      flush_section()
      section = $0
      sub(/^[[:space:]]*\[/, "", section)
      sub(/\].*$/, "", section)
      gsub(/^[[:space:]]+|[[:space:]]+$/, "", section)
    }

    {
      count++
      lines[count] = $0
    }

    END {
      flush_section()
    }
  ' "$file" > "$tmp"

  if ! cmp -s "$tmp" "$file"; then
    backup_file "$file"
    cat "$tmp" > "$file"
  fi
  rm -f "$tmp"
}

ensure_nginx_webrtc_proxy() {
  local file=""

  if [ -f /etc/nginx/sites-available/xema.nginx ]; then
    file="/etc/nginx/sites-available/xema.nginx"
  elif [ -f /etc/nginx/sites-enabled/xema.nginx ]; then
    file="/etc/nginx/sites-enabled/xema.nginx"
  else
    echo "Nginx Xema site not found; skipping /ws proxy setup"
    return 0
  fi

  if grep -q "proxy_pass http://127.0.0.1:8088/ws" "$file"; then
    return 0
  fi

  backup_file "$file"
  local tmp
  tmp="$(mktemp)"

  awk '
    BEGIN { inserted = 0 }
    /^[[:space:]]*location[[:space:]]+(\/sysadms|\/interconnect|= \/netdata)/ && !inserted {
      print "    location /ws {"
      print "        proxy_pass http://127.0.0.1:8088/ws;"
      print "        proxy_http_version 1.1;"
      print "        proxy_set_header Upgrade $http_upgrade;"
      print "        proxy_set_header Connection \"Upgrade\";"
      print "        proxy_set_header Host $host;"
      print "        proxy_read_timeout 3600s;"
      print "        proxy_send_timeout 3600s;"
      print "    }"
      print ""
      inserted = 1
    }
    { print }
  ' "$file" > "$tmp"

  if ! grep -q "proxy_pass http://127.0.0.1:8088/ws" "$tmp"; then
    echo "Could not safely insert nginx /ws location in $file" >&2
    rm -f "$tmp"
    return 1
  fi

  cat "$tmp" > "$file"
  rm -f "$tmp"

  if [ -d /etc/nginx/sites-enabled ] && [ ! -e /etc/nginx/sites-enabled/xema.nginx ]; then
    ln -s "$file" /etc/nginx/sites-enabled/xema.nginx
  fi

  nginx -t
  systemctl reload nginx
}

ensure_nginx_https_redirect() {
  local file=""

  if [ -f /etc/nginx/sites-available/xema.nginx ]; then
    file="/etc/nginx/sites-available/xema.nginx"
  elif [ -f /etc/nginx/sites-enabled/xema.nginx ]; then
    file="/etc/nginx/sites-enabled/xema.nginx"
  else
    echo "Nginx Xema site not found; skipping HTTPS redirect setup"
    return 0
  fi

  if grep -q 'return 301 https://\$host\$request_uri' "$file"; then
    return 0
  fi

  if ! grep -qE '^[[:space:]]*listen[[:space:]]+80;' "$file"; then
    echo "Nginx Xema site has no listen 80 line; skipping HTTPS redirect setup"
    return 0
  fi

  backup_file "$file"
  local tmp
  tmp="$(mktemp)"

  awk '
    /^[[:space:]]*listen[[:space:]]+80;/ && !inserted {
      print
      print "    server_name _;"
      print "    return 301 https://$host$request_uri;"
      print "}"
      print ""
      print "server {"
      inserted = 1
      next
    }
    { print }
  ' "$file" > "$tmp"

  if ! grep -q 'return 301 https://\$host\$request_uri' "$tmp"; then
    echo "Could not safely insert nginx HTTPS redirect in $file" >&2
    rm -f "$tmp"
    return 1
  fi

  cat "$tmp" > "$file"
  rm -f "$tmp"

  nginx -t
  systemctl reload nginx
}

ensure_self_contained_service() {
  if [ ! -x /var/lib/xema/manager/Manager ]; then
    echo "Self-contained Manager executable not found; keeping existing service ExecStart"
    return 0
  fi

  mkdir -p /etc/systemd/system/xema-manager.service.d
  cat >/etc/systemd/system/xema-manager.service.d/self-contained.conf <<'EOF'
[Service]
ExecStart=
ExecStart=/var/lib/xema/manager/Manager
EOF

  systemctl daemon-reload
}

ensure_asterisk_config_access
ensure_asterisk_media_access
if [ "${1:-}" = --asterisk-access-only ]; then
  echo 'Asterisk config/media access applied; no file contents, services or SIP routing changed.'
  exit 0
fi
ensure_certificates
ensure_asterisk_http_tls
ensure_asterisk_modules
ensure_pjsip_transport_binds
ensure_nginx_webrtc_proxy
ensure_nginx_https_redirect
ensure_self_contained_service

cat <<'EOF'
XEMA runtime prerequisites applied.

If Asterisk was already running, restart it during a maintenance window so
modules.conf load-order changes take effect:
  sudo systemctl restart asterisk

Then restart Manager if a new backend package was deployed:
  sudo systemctl restart xema-manager
EOF
