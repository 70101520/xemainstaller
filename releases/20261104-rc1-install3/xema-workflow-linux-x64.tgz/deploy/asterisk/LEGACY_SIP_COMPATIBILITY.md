# Explicit Legacy SIP Compatibility (Asterisk 20)

XEMA's existing BSNL/TATA and Generic SIP trunk types generate `sip.conf` and
`SIP/...` dial strings. They require `chan_sip.so`. The local Sip Client w/Auth
test trunk and PJSIP trunk types use `chan_pjsip` instead. These are separate
drivers; `sip show peers` does not list PJSIP endpoints.

Fresh installations retain the PJSIP-only module default. A reviewed site may
explicitly enable legacy SIP on Asterisk 20. The runtime helper now preserves an
active `load`, `preload` or `require` directive for `chan_sip.so`, rather than
adding a conflicting `noload`. Conflicting active directives fail for review.
It never enables legacy SIP automatically or changes transports, VPN or routes.

## Site Prerequisites

- Confirm `chan_sip.so` is installed. It is deprecated and removed from Asterisk
  21 onward; a newer major version is not a drop-in fix for a legacy trunk.
- Configure the ISP VPN and local addresses first. Keep legacy SIP and PJSIP
  binds disjoint by local address, port or protocol. A PJSIP wildcard UDP bind
  conflicts with legacy SIP on the same IPv4 UDP port.
- Verify the actual running PJSIP transport binds, not just the file. In the
  verified deployment, legacy SIP used a VPN IPv4 and PJSIP a different LAN IPv4;
  both used UDP 5060. Legacy TCP was disabled. Do not copy those site addresses.
- Restrict provider access appropriately. This change does not manage firewall
  rules or make a deprecated driver safe for unrestricted public exposure.
- Verify zero active channels/calls and an empty concise channel list before
  module policy changes. Defer if the checks fail or calls are active.

## Reviewed Manual Setup

Retain a root-only backup of `modules.conf`, `sip.conf`, `pjsip.conf`,
`pjsip_wizard.conf` and `extensions.conf`. Do not copy credentials into Git.
In `modules.conf`, replace only the reviewed active directive:

```ini
; Before
noload => chan_sip.so
; After (do not retain both active directives)
load => chan_sip.so
```

After verifying that the intended VPN bind is local and free, load only the new
module. Do not restart the working PBX or change PJSIP transport binds:

```bash
asterisk -rx 'module load chan_sip.so'
asterisk -rx 'module show like chan_sip.so'
asterisk -rx 'sip show registry'
asterisk -rx 'sip show peers'
asterisk -rx 'pjsip show contacts'
```

Registration/peer availability is not an actual inbound/outbound, RTP, IVR, Agent,
CDR or recording acceptance test. Validate the provider's real incoming DNIS
format before changing exact GUI DNIS rules; do not add a catch-all blindly.

For rollback, retain the exact module-policy backup. Never unload a driver or
restart a service with calls active. If VPN startup is delayed after a reboot,
verify the legacy bind and registration again after the VPN is available.
This change does not claim reboot/startup ordering or a major-version migration
was tested.

References:
- https://docs.asterisk.org/Configuration/Channel-Drivers/SIP/Configuring-res_pjsip/Migrating-from-chan_sip-to-res_pjsip/
- https://docs.asterisk.org/Configuration/Channel-Drivers/SIP/Configuring-chan_sip/
- https://docs.asterisk.org/About-the-Project/Asterisk-Versions/
