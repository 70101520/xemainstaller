#!/usr/bin/env python3
"""New-site bootstrap only; never rotate/reset an existing site's credentials or data."""
import base64
import hashlib
import ipaddress
import json
import os
from pathlib import Path, PurePosixPath
import re
import secrets
import shutil
import subprocess
import sys
import tarfile
import time
import urllib.request
import zipfile

HERE = Path(__file__).resolve().parent
CACHE = Path('/var/cache/xema-install')
SECRETS = Path('/etc/xema/install-secrets.json')
COMPONENTS = {'FastAGI': 'fastagi', 'AsterMQ': 'astermq', 'SimpleCdr': 'simplecdr',
              'Bff': 'bff', 'Tracer': 'tracer', 'Sipper': 'sipper', 'MissingCdrs': 'import',
              'Ava': 'ava', 'Metrics': 'metrics', 'MetricsBackfill': 'backfill', 'Cli': 'cli'}
WORKER_DATABASES = ('SimpleCdrWorker', 'Sipper')
DATABASES = ('Auth', 'Xema', 'Data', 'Logs', 'Hangfire', 'Metrics', 'SimpleCdr') + WORKER_DATABASES


def run(args, **kwargs):
    return subprocess.run(args, check=True, text=True, **kwargs)


def write(path, text, mode=0o600):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
    path.chmod(mode)


def sip_networks(value):
    entries = value.split(',')
    if not value.strip() or any(not entry.strip() for entry in entries):
        raise SystemExit('XEMA_SIP_CIDRS must explicitly list trusted provider/LAN/VPN networks.')
    networks = [ipaddress.ip_network(entry.strip(), strict=False) for entry in entries]
    if any(network.prefixlen == 0 for network in networks):
        raise SystemExit('Unrestricted SIP access is not a safe fresh-install default.')
    return list(dict.fromkeys(str(network) for network in networks))


def site_origin():
    host = os.environ.get('XEMA_PUBLIC_HOST') or os.environ.get('XEMA_SERVER_IP') or 'localhost'
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9.-]*', host):
        raise SystemExit('Invalid installation hostname/IP.')
    return 'https://' + host


def preflight():
    sip_networks(os.environ.get('XEMA_SIP_CIDRS', ''))
    site_origin()
    if SECRETS.exists() or Path('/etc/asterisk').exists() or Path('/var/lib/xema/manager/appsettings.json').exists():
        raise SystemExit('Existing PBX/site found: fresh installation refused; use the reviewed upgrade path.')
    application = Path('/var/lib/xema')
    if application.exists() and any(application.iterdir()):
        raise SystemExit('Existing XEMA files found: fresh installation refused.')
    enabled = Path('/etc/nginx/sites-enabled')
    if enabled.exists() and any(path.name != 'default' for path in enabled.iterdir()):
        raise SystemExit('Existing custom nginx site found: fresh installation refused.')


def fresh_sip_and_proxy(root=Path('/')):
    # Fresh-host bootstrap only, never the existing-site upgrade path.
    configuration = ''.join(f'[{name}]\ntype=transport\nprotocol={protocol}\nbind=0.0.0.0\n'
                            for name, protocol in (('transport-udp', 'udp'), ('transport-tcp', 'tcp'), ('transport-wss', 'wss')))
    write(root / 'etc/asterisk/pjsip.conf', configuration, 0o640)
    site = root / 'etc/nginx/sites-available/xema.nginx'
    write(site, (HERE / 'xema-secure.nginx').read_text(), 0o644)
    enabled = root / 'etc/nginx/sites-enabled'
    enabled.mkdir(parents=True, exist_ok=True)
    (enabled / 'xema.nginx').symlink_to(site)
    default = enabled / 'default'
    if default.is_symlink():
        default.unlink()


def component_options(data, secret):
    sections = {
        'MariaDb': dict(Server='localhost', UserName='xema', Password=secret['sql']),
        'Asterisk': dict(Server='localhost', UserName='xema', Password=secret['asterisk']),
        'Ari': dict(Host='localhost', Username='xema', Password=secret['asterisk']),
        'RabbitMq': dict(Host='localhost', UserName='xema', Password=secret['rabbit']),
        'Redis': dict(UseConnectionString=True, ConnectionString='localhost:6379,password=' + secret['redis']),
        'System': dict(AutoUpdate=False)
    }
    for name, updates in sections.items():
        matches = [key for key in data if key.casefold() == name.casefold()]
        if len(matches) > 1:
            raise ValueError('Duplicate configuration section: ' + name)
        if not matches:
            continue
        section = data[matches[0]]
        for key, value in updates.items():
            # .NET keys are case-insensitive; Python dict.update is not.
            for previous in list(section):
                if previous.casefold() == key.casefold():
                    del section[previous]
            section[key] = value
    return data


def backup():
    if Path('/var/lib/xema/manager/appsettings.json').exists():
        raise SystemExit('Existing site configuration found: fresh installation refused.')
    root = Path('/root') / time.strftime('xema-fresh-backup-%Y%m%d-%H%M%S')
    root.mkdir(mode=0o700)
    with tarfile.open(root / 'configuration.tgz', 'w:gz') as archive:
        for path in ('/etc/asterisk', '/etc/nginx', '/etc/mysql', '/etc/redis', '/etc/rabbitmq', '/etc/ufw'):
            if Path(path).exists():
                archive.add(path, arcname=path.lstrip('/'))
    print('Initial configuration backup: ' + str(root))
    if shutil.which('mariadb'):
        names = run(['mariadb', '-N', '-B', '-e', 'SHOW DATABASES'], capture_output=True).stdout.splitlines()
        names = [name for name in DATABASES if name in names]
        if names:
            with (root / 'application-databases.sql').open('w') as output:
                run(['mariadb-dump', '--single-transaction', '--routines', '--events', '--databases', *names], stdout=output)


def download():
    lock = json.loads((HERE / 'xema-base-assets.lock.json').read_text())
    if lock.get('schemaVersion') != 1:
        raise SystemExit('Invalid base asset lock.')
    CACHE.mkdir(parents=True, exist_ok=True, mode=0o700)
    for asset in lock['assets']:
        name, url, digest = asset['name'], asset['url'], asset['sha256']
        if Path(name).name != name or not url.startswith('https://') or len(digest) != 64:
            raise SystemExit('Unsafe base asset metadata.')
        target = CACHE / name
        if not target.exists() or hashlib.sha256(target.read_bytes()).hexdigest() != digest:
            with urllib.request.urlopen(url, timeout=90) as response, target.open('wb') as output:
                shutil.copyfileobj(response, output)
        if hashlib.sha256(target.read_bytes()).hexdigest() != digest:
            target.unlink()
            raise SystemExit('Base asset checksum mismatch: ' + name)
        print('Verified base asset: ' + name, flush=True)


def configure():
    if SECRETS.exists():
        raise SystemExit('Existing installation secrets found; refusing implicit credential rotation.')
    networks = sip_networks(os.environ.get('XEMA_SIP_CIDRS', ''))
    origin = site_origin()
    import json5
    admin = os.environ.get('SUDO_USER', '')
    if not admin or admin == 'root':
        admin = os.environ.get('XEMA_INSTALL_ADMIN', '')
    if not admin or not run(['getent', 'passwd', admin], capture_output=True).stdout:
        raise SystemExit('Explicit existing Linux installation administrator required.')
    for name in COMPONENTS:
        with zipfile.ZipFile(CACHE / (name + '.zip')) as archive:
            for member in archive.infolist():
                path = PurePosixPath(member.filename)
                if path.is_absolute() or '..' in path.parts or '\\' in member.filename or ':' in member.filename or (member.external_attr >> 16) & 0o170000 == 0o120000:
                    raise SystemExit('Unsafe ZIP member: ' + member.filename)
                if path.name.startswith('appsettings') and path.suffix == '.json':
                    json5.loads(archive.read(member).decode('utf-8-sig'))
    secret = {name: secrets.token_hex(32) for name in ('sql', 'asterisk', 'rabbit', 'redis')}
    write(SECRETS, json.dumps(secret, indent=2))
    SECRETS.parent.chmod(0o700)
    for name, directory in COMPONENTS.items():
        target = Path('/var/lib/xema') / directory
        target.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(CACHE / (name + '.zip')) as archive:
            for member in archive.infolist():
                path = PurePosixPath(member.filename)
                if path.is_absolute() or '..' in path.parts or '\\' in member.filename or ':' in member.filename or (member.external_attr >> 16) & 0o170000 == 0o120000:
                    raise SystemExit('Unsafe ZIP member: ' + member.filename)
            archive.extractall(target)
        for settings_path in target.glob('appsettings*.json'):
            data = json5.loads(settings_path.read_text(encoding='utf-8-sig'))
            component_options(data, secret)
            write(settings_path, json.dumps(data, indent=2))
    settings = {
        'System': {'AutoUpdate': False, 'EnableLanDiscovery': False, 'AdminUsers': [admin, 'root'], 'AgentPortal': origin},
        'MariaDb': {'Server': 'localhost', 'UserName': 'xema', 'Password': secret['sql']},
        'Asterisk': {'Server': 'localhost', 'UserName': 'xema', 'Password': secret['asterisk']},
        'RabbitMq': {'Host': 'localhost', 'Username': 'xema', 'Password': secret['rabbit']},
        'Redis': {'UseConnectionString': True, 'ConnectionString': 'localhost:6379,password=' + secret['redis']},
        'Logging': {'LogLevel': {'Default': 'Warning'}}, 'AllowedHosts': '*'
    }
    write('/var/lib/xema/manager/appsettings.json', json.dumps(settings, indent=2))
    for name in CACHE.glob('*.service'):
        unit = name.read_text()
        if 'ExecStart=' not in unit or 'ExecStartPre=' in unit or 'ExecStartPost=' in unit:
            raise SystemExit('Unreviewed service unit: ' + name.name)
        write(Path('/etc/systemd/system') / name.name, unit, 0o644)
    write('/etc/systemd/system/xema-manager.service', '''[Unit]
Description=XEMA Manager
After=network-online.target mariadb.service rabbitmq-server.service redis-server.service asterisk.service
[Service]
WorkingDirectory=/var/lib/xema/manager
ExecStart=/var/lib/xema/manager/Manager
Environment=ASPNETCORE_ENVIRONMENT=Production
Environment=ASPNETCORE_URLS=http://127.0.0.1:4200
Restart=on-failure
UMask=0027
[Install]
WantedBy=multi-user.target
''', 0o644)
    write('/etc/rabbitmq/rabbitmq.conf', 'listeners.tcp.default = 127.0.0.1:5672\n', 0o640)
    shutil.chown('/etc/rabbitmq/rabbitmq.conf', user='rabbitmq', group='rabbitmq')
    write('/etc/mysql/mariadb.conf.d/99-xema-bind.cnf', '[mysqld]\nbind-address=127.0.0.1\n', 0o644)
    with Path('/etc/redis/redis.conf').open('a') as output:
        output.write('\n# XEMA fresh install\nbind 127.0.0.1 ::1\nprotected-mode yes\nrequirepass ' + secret['redis'] + '\n')
    for source, target in (('asterisk-master-csv', '/etc/logrotate.d/asterisk-master-csv'),
                           ('prometheus.yml', '/etc/prometheus/prometheus.yml'),
                           ('target-xema.json', '/etc/prometheus/target-xema.json')):
        shutil.copy2(CACHE / source, target)
        Path(target).chmod(0o644)
    write('/etc/default/prometheus', 'ARGS="--web.listen-address=127.0.0.1:9090 --config.file=/etc/prometheus/prometheus.yml"\n', 0o644)
    write('/etc/asterisk/manager.conf', '[general]\nenabled=yes\nport=5038\nbindaddr=127.0.0.1\ntimestampevents=yes\n[xema]\nsecret=' + secret['asterisk'] + '\ndeny=0.0.0.0/0.0.0.0\npermit=127.0.0.1/255.255.255.255\nread=all\nwrite=all\n', 0o640)
    write('/etc/asterisk/ari.conf', '[general]\nenabled=yes\n[xema]\ntype=user\nread_only=no\npassword=' + secret['asterisk'] + '\n', 0o640)
    for name in ('manager.conf', 'ari.conf'):
        shutil.chown(Path('/etc/asterisk') / name, user='root', group='asterisk')
    fresh_sip_and_proxy()
    shutil.chown('/etc/asterisk/pjsip.conf', user='root', group='asterisk')
    # Keep existing firewall rules; never disable UFW or import another person's SSH key.
    sshd = run(['/usr/sbin/sshd', '-T'], capture_output=True).stdout.splitlines()
    ports = [line.split()[1] for line in sshd if line.startswith('port ')]
    if not ports or any(not port.isdigit() for port in ports):
        raise SystemExit('Cannot determine actual SSH port; firewall activation refused.')
    for port in ports:
        run(['ufw', 'allow', port + '/tcp'])
    run(['ufw', 'allow', '80/tcp'])
    run(['ufw', 'allow', '443/tcp'])
    run(['ufw', 'default', 'deny', 'incoming'])
    for network in networks:
        for protocol in ('udp', 'tcp'):
            run(['ufw', 'allow', 'from', network, 'to', 'any', 'port', '5060', 'proto', protocol])
        run(['ufw', 'allow', 'from', network, 'to', 'any', 'port', '10000:20000', 'proto', 'udp'])
    run(['ufw', '--force', 'enable'])


def database_grants(databases):
    if any(name not in DATABASES for name in databases):
        raise ValueError('Unreviewed application schema.')
    return ''.join(f'CREATE DATABASE IF NOT EXISTS `{name}`; '
                   f"GRANT ALL PRIVILEGES ON `{name}`.* TO 'xema'@'localhost';\n"
                   for name in databases)


def accounts():
    secret = json.loads(SECRETS.read_text())
    sql = "CREATE USER 'xema'@'localhost' IDENTIFIED BY '" + secret['sql'] + "';\n"
    sql += database_grants(DATABASES)
    # Legacy bootstrap/report connections select mysql as their default database.
    # Permit only this non-sensitive metadata table, never mysql.user or global grants.
    sql += "GRANT SELECT ON mysql.time_zone_name TO 'xema'@'localhost';\n"
    run(['mariadb'], input=sql, stdout=subprocess.DEVNULL)
    rabbit_account(secret)
    print('Created unique local service credentials and schema-scoped SQL grants; no passwords printed.')


def rabbit_account(secret):
    salt = secrets.token_bytes(4)
    password_hash = base64.b64encode(salt + hashlib.sha256(salt + secret['rabbit'].encode()).digest()).decode()
    definitions = {'users': [{'name': 'xema', 'password_hash': password_hash,
                             'hashing_algorithm': 'rabbit_password_hashing_sha256', 'tags': []}],
                   'vhosts': [{'name': '/'}],
                   'permissions': [{'user': 'xema', 'vhost': '/', 'configure': '.*', 'write': '.*', 'read': '.*'}]}
    # The distribution CLI wrapper switches user; it cannot read root-only paths.
    # Send the hashed definitions over stdin, never process arguments or public files.
    run(['rabbitmqctl', 'import_definitions'], input=json.dumps(definitions), stdout=subprocess.DEVNULL)
    run(['rabbitmqctl', 'delete_user', 'guest'], stdout=subprocess.DEVNULL)


if __name__ == '__main__':
    os.umask(0o077)
    if os.geteuid() != 0:
        raise SystemExit('Root required.')
    actions = {'preflight': preflight, 'backup': backup, 'download': download, 'configure': configure, 'accounts': accounts}
    if len(sys.argv) != 2 or sys.argv[1] not in actions:
        raise SystemExit('Expected preflight/backup/download/configure/accounts.')
    actions[sys.argv[1]]()
