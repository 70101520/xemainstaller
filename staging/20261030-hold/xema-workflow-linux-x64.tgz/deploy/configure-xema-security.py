#!/usr/bin/env python3
"""Preserve site credentials while setting explicit Admin/CORS policy."""
import json
import os
from pathlib import Path
import pwd
import sys
import tempfile


def config_key(mapping, name):
    matches = [key for key in mapping if key.casefold() == name.casefold()]
    if len(matches) > 1:
        raise ValueError("Duplicate case-insensitive configuration key: " + name)
    return matches[0] if matches else name


def configure(path, admin_users=None):
    data = json.loads(path.read_text(encoding="utf-8-sig"))
    system = data.setdefault(config_key(data, "System"), {})
    users_key = config_key(system, "AdminUsers")
    origins_key = config_key(system, "AllowedOrigins")
    if admin_users is not None:
        users = [user.strip() for user in admin_users.split(",") if user.strip()]
    elif users_key in system:
        users = system[users_key]
    else:
        users = ["root"]
        installer = os.environ.get("SUDO_USER", "")
        if installer and installer != "root":
            users.append(installer)
    if not isinstance(users, list) or not users or any(not isinstance(user, str) for user in users):
        raise ValueError("AdminUsers must explicitly name at least one Linux administrator")
    for user in users:
        pwd.getpwnam(user)
    system[users_key] = list(dict.fromkeys(users))
    system.setdefault(origins_key, [])
    # Production overrides must not silently re-enable broader access.
    override = path.with_name("appsettings.Production.json")
    if override.exists():
        overrides = json.loads(override.read_text(encoding="utf-8-sig"))
        override_system = overrides.get(config_key(overrides, "System"), {})
        if any(key.casefold() in ("adminusers", "allowedorigins") for key in override_system):
            raise ValueError("Move AdminUsers/AllowedOrigins from appsettings.Production.json into appsettings.json first")
    stat = path.stat()
    descriptor, temporary = tempfile.mkstemp(prefix=".security-", dir=path.parent)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
            json.dump(data, stream, indent=2)
            stream.write("\n")
        os.chmod(temporary, 0o600)
        os.chown(temporary, stat.st_uid, stat.st_gid)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)
    print("Admin allowlist: " + ", ".join(system[users_key]))


if __name__ == "__main__":
    configure(Path(sys.argv[1]), os.environ.get("XEMA_ADMIN_USERS"))
