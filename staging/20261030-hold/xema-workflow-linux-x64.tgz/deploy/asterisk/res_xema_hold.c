/* SPDX-License-Identifier: GPL-2.0-only */
/* XEMA native bridge Hold/Unhold. No parking, redirect or new SIP leg. */
#include "asterisk.h"
#include "asterisk/module.h"
#include "asterisk/manager.h"
#include "asterisk/channel.h"
#include "asterisk/bridge.h"
#include "asterisk/astobj2.h"
#include "asterisk/pbx.h"
#include "asterisk/framehook.h"

#define HOLD_PEER "XEMA_NATIVE_HOLD_PEER"
#define HOLD_BRIDGE "XEMA_NATIVE_HOLD_BRIDGE"

struct hold_audio { int hook_id; };

static void audio_destroy(void *data) { ao2_cleanup(data); }
static const struct ast_datastore_info audio_store = {
    .type = "xema_native_hold", .destroy = audio_destroy,
};

static struct ast_frame *mute_frame(struct ast_channel *channel, struct ast_frame *frame,
    enum ast_framehook_event event, void *data)
{
    if (frame && frame->frametype == AST_FRAME_VOICE &&
        (event == AST_FRAMEHOOK_EVENT_READ || event == AST_FRAMEHOOK_EVENT_WRITE)) {
        if (event == AST_FRAMEHOOK_EVENT_READ) ast_frfree(frame);
        return &ast_null_frame;
    }
    return frame;
}

static void hook_destroy(void *data)
{
    ao2_cleanup(data);
    ast_module_unref(ast_module_info->self);
}

static void hook_fixup(void *data, int id, struct ast_channel *old_channel, struct ast_channel *new_channel)
{
    struct hold_audio *audio = data;
    audio->hook_id = id;
}

static int mute_audio(struct ast_channel *channel)
{
    struct ast_datastore *store;
    struct hold_audio *audio;
    struct ast_framehook_interface hook = {
        .version = AST_FRAMEHOOK_INTERFACE_VERSION,
        .event_cb = mute_frame, .destroy_cb = hook_destroy,
        .chan_fixup_cb = hook_fixup,
    };
    if (ast_channel_datastore_find(channel, &audio_store, NULL)) return 0;
    store = ast_datastore_alloc(&audio_store, NULL);
    audio = ao2_alloc(sizeof(*audio), NULL);
    if (!store || !audio) {
        if (store) ast_datastore_free(store);
        ao2_cleanup(audio);
        return -1;
    }
    ast_module_ref(ast_module_info->self);
    hook.data = audio;
    audio->hook_id = ast_framehook_attach(channel, &hook);
    if (audio->hook_id < 0) {
        ast_module_unref(ast_module_info->self);
        ast_datastore_free(store);
        ao2_cleanup(audio);
        return -1;
    }
    ao2_ref(audio, +1);
    store->data = audio;
    ast_channel_datastore_add(channel, store);
    return 0;
}

static void unmute_audio(struct ast_channel *channel)
{
    struct ast_datastore *store = ast_channel_datastore_find(channel, &audio_store, NULL);
    if (store) {
        struct hold_audio *audio = store->data;
        ast_framehook_detach(channel, audio->hook_id);
        ast_channel_datastore_remove(channel, store);
        ast_datastore_free(store);
    }
}

static int hold_action(struct mansession *session, const struct message *message)
{
    const char *name = astman_get_header(message, "Channel");
    const char *uniqueid = astman_get_header(message, "Uniqueid");
    const char *peerid = astman_get_header(message, "PeerUniqueid");
    const char *bridgeid = astman_get_header(message, "BridgeId");
    const char *state = astman_get_header(message, "State");
    const char *current_peer;
    char *error = NULL;
    struct ast_channel *channel = NULL, *peer = NULL;
    struct ast_bridge *bridge = NULL;
    int held, result = -1;

    if (ast_strlen_zero(uniqueid) || ast_strlen_zero(peerid) || ast_strlen_zero(bridgeid) ||
        strncmp(name, "PJSIP/", 6) || !strncmp(name, "PJSIP/trunk_", 12) ||
        (strcmp(state, "on") && strcmp(state, "off"))) {
        astman_send_error(session, message, "Valid phone, unique IDs, bridge and on/off State required");
        return 0;
    }
    held = !strcmp(state, "on");
    channel = ast_channel_get_by_name(name);
    if (!channel) {
        astman_send_error(session, message, "Phone channel no longer exists");
        return 0;
    }
    peer = ast_channel_bridge_peer(channel);
    if (!peer || strcmp(ast_channel_uniqueid(peer), peerid)) {
        error = "Call peer changed or bridge is not two-party";
        goto done;
    }
    ast_channel_lock_both(channel, peer);
    bridge = ast_channel_get_bridge(channel);
    if (!bridge || strcmp(bridge->uniqueid, bridgeid) ||
        strcmp(ast_channel_uniqueid(channel), uniqueid) ||
        ast_channel_state(channel) != AST_STATE_UP || ast_check_hangup_locked(channel)) {
        error = "Phone channel or bridge changed before Hold/Unhold";
        goto unlock;
    }
    current_peer = pbx_builtin_getvar_helper(channel, HOLD_PEER);
    if (held && !ast_strlen_zero(current_peer) && !strcmp(current_peer, ast_channel_name(peer))) {
        result = 0;
        goto unlock;
    }
    if (!held && ast_strlen_zero(current_peer)) {
        result = 0;
        goto unlock;
    }
    if (!held && strcmp(current_peer, ast_channel_name(peer))) {
        error = "The held peer does not match this call";
        goto unlock;
    }
    if (held && mute_audio(channel)) {
        error = "Could not mute the agent audio safely";
        goto unlock;
    }
    /* These core APIs publish the normal AMI Hold/Unhold events, so the
       existing phone state and CHAN_HOLD/CHAN_UNHOLD CDR path are retained. */
    result = held ? ast_queue_hold(channel, NULL) : ast_queue_unhold(channel);
    if (!held || result) unmute_audio(channel);
    if (!result) {
        pbx_builtin_setvar_helper(channel, HOLD_PEER, held ? ast_channel_name(peer) : NULL);
        pbx_builtin_setvar_helper(channel, HOLD_BRIDGE, held ? bridgeid : NULL);
    } else {
        error = "Could not queue native Hold/Unhold";
    }
unlock:
    ast_channel_unlock(channel);
    ast_channel_unlock(peer);
done:
    ao2_cleanup(bridge);
    ast_channel_cleanup(peer);
    ast_channel_cleanup(channel);
    if (error || result) astman_send_error(session, message, error ? error : "Native hold failed");
    else astman_send_ack(session, message, held ? "Native Hold queued" : "Native Unhold queued");
    return 0;
}

static int load_module(void)
{
    return ast_manager_register2("XemaChannelHold", EVENT_FLAG_CALL, hold_action,
        ast_module_info->self,
        "Hold or resume an existing two-party phone call without parking",
        "Channel, Uniqueid, PeerUniqueid, BridgeId and State (on/off) are required.")
        ? AST_MODULE_LOAD_DECLINE : AST_MODULE_LOAD_SUCCESS;
}

static int unload_module(void)
{
    return ast_manager_unregister("XemaChannelHold");
}

AST_MODULE_INFO_STANDARD(ASTERISK_GPL_KEY, "XEMA native channel Hold/Unhold");
