#!/usr/bin/env python3
"""Non-destructive entry-boundary checks; password is read from the terminal."""
import getpass
import base64
from html.parser import HTMLParser
from http.cookiejar import CookieJar
import json
import os
import socket
import ssl
import sys
import urllib.error
import urllib.parse
import urllib.request


class LoginForm(HTMLParser):
    token = None

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == "input" and attrs.get("name") == "__RequestVerificationToken":
            self.token = attrs.get("value")


base = sys.argv[1].rstrip("/")
username = sys.argv[2] if len(sys.argv) > 2 else "xema"
tls = ssl.create_default_context(cafile="/etc/ssl/certs/certificate.pem")
jar = CookieJar()
client = urllib.request.build_opener(urllib.request.HTTPSHandler(context=tls), urllib.request.HTTPCookieProcessor(jar))


def request(path, data=None, headers=None):
    req = urllib.request.Request(base + path, data=data, headers=headers or {})
    try:
        response = client.open(req, timeout=20)
    except urllib.error.HTTPError as error:
        response = error
    return response.status, response.headers, response.read().decode("utf-8", errors="replace")


for route, expected in [("/", 200), ("/hangfire/", 401), ("/netdata/api/v1/info", 401),
                        ("/api/security/diagnostics", 401), ("/api/Devices/GetDevices", 401),
                        ("/api/LiveView/Summary", 401), ("/api/Reports/Reports", 401)]:
    status, headers, body = request(route)
    assert status == expected, (route, status, expected)
    assert headers.get("X-Content-Type-Options") == "nosniff", route
    print(f"PASS anonymous {route}: {status}")

status, headers, body = request("/api/Setup/Ping", headers={"Origin": "https://192.168.252.222:9443"})
assert headers.get("Access-Control-Allow-Origin") is None
print("PASS unconfigured LAN origin is not trusted")

status, _, body = request("/Admin/Login")
form = LoginForm()
form.feed(body)
assert status == 200 and form.token
invalid = urllib.parse.urlencode({"Username": "xema-security-unlisted-user", "Password": "invalid-test-only",
                                 "__RequestVerificationToken": form.token}).encode()
status, _, body = request("/Admin/Login", data=invalid)
assert status == 200 and "Invalid username or password" in body
assert not any(cookie.name == ".Xema.Admin.v2" for cookie in jar)
print("PASS unlisted Linux user rejected, including Debug version deployments")

form = LoginForm()
form.feed(body)
password = getpass.getpass(f"Admin password for {username}: ")
login = urllib.parse.urlencode({"Username": username, "Password": password,
                               "__RequestVerificationToken": form.token}).encode()
del password
status, _, _ = request("/Admin/Login", data=login)
del login
assert status == 200, status
cookies = [cookie for cookie in jar if cookie.name == ".Xema.Admin.v2"]
print("Cookie attributes:", [(cookie.name, cookie.secure, list(cookie._rest)) for cookie in jar])
assert len(cookies) == 1 and cookies[0].secure and any(key.lower() == "httponly" for key in cookies[0]._rest)
print("PASS configured Admin password login; Secure/HttpOnly cookie")
for route, expected in [("/api/security/diagnostics", 204), ("/hangfire/", 200), ("/netdata/api/v1/info", 200)]:
    status, _, _ = request(route)
    assert status == expected, (route, status, expected)
    print(f"PASS authenticated Admin {route}: {status}")
jar.clear()
status, _, _ = request("/api/security/diagnostics")
assert status == 401
print("PASS diagnostics require a session; certificate IP validation succeeded")

# Test only the SIP WebSocket upgrade, without registering a phone or placing a call.
address = urllib.parse.urlparse(base)
websocket_key = base64.b64encode(os.urandom(16)).decode()
with socket.create_connection((address.hostname, address.port or 443), timeout=10) as raw:
    with tls.wrap_socket(raw, server_hostname=address.hostname) as connection:
        connection.sendall((f"GET /ws HTTP/1.1\r\nHost: {address.netloc}\r\n"
                            "Upgrade: websocket\r\nConnection: Upgrade\r\n"
                            f"Sec-WebSocket-Key: {websocket_key}\r\n"
                            "Sec-WebSocket-Version: 13\r\nSec-WebSocket-Protocol: sip\r\n\r\n").encode())
        response = connection.recv(4096).decode("ascii", errors="replace")
        assert response.startswith("HTTP/1.1 101"), response.splitlines()[0]
        connection.sendall(b"\x88\x80" + os.urandom(4))
print("PASS same-certificate /ws SIP WebSocket upgrade: 101; no calls or registration performed")
