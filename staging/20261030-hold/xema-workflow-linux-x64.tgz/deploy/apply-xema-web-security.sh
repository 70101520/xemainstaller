#!/usr/bin/env bash
set -euo pipefail
[ "$(id -u)" -eq 0 ] || { echo 'Run as root.' >&2; exit 1; }
here="$(cd -- "$(dirname -- "$0")" && pwd)"
manager="${XEMA_MANAGER_DIR:-/var/lib/xema/manager}"
backup="${XEMA_SECURITY_BACKUP:-/root/xema-web-security-$(date +%Y%m%d-%H%M%S)}"
site="$(readlink -f /etc/nginx/sites-enabled/xema.nginx)"
test -f "$site"
test -s "$manager/appsettings.json"
mkdir -p -m 0700 "$backup"
for path in "$manager/appsettings.json" "$site" /etc/ssl/certs/certificate.pem /etc/ssl/private/key.pem /etc/nginx/snippets/xema-proxy-security.conf; do
    if [ -e "$path" ]; then cp -a --parents "$path" "$backup/"; fi
done
rollback() {
    result=$?
    trap - ERR
    for path in "$manager/appsettings.json" "$site" /etc/ssl/certs/certificate.pem /etc/ssl/private/key.pem /etc/nginx/snippets/xema-proxy-security.conf; do
        if [ -e "$backup$path" ]; then cp -a "$backup$path" "$path"; fi
    done
    nginx -t && systemctl reload nginx || true
    echo "Web security setup failed; configuration restored from $backup" >&2
    exit "$result"
}
trap rollback ERR

# Replacing a stock site is explicit; customized sites require operator review.
if ! grep -q 'XEMA managed security configuration v1' "$site" && [ "${XEMA_REPLACE_STOCK_NGINX:-0}" != 1 ]; then
    echo 'Review your nginx site, then set XEMA_REPLACE_STOCK_NGINX=1 for the stock XEMA proxy layout.' >&2
    false
fi
python3 "$here/configure-xema-security.py" "$manager/appsettings.json"

ip="${XEMA_SERVER_IP:-}"
if [ -z "$ip" ]; then
    ip="$(ip -4 route get 1.1.1.1 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i=="src") {print $(i+1); exit}}' || true)"
fi
if [ -z "$ip" ]; then
    ip="$(ip -o -4 addr show scope global | awk '{split($4,address,"/"); print address[1]; exit}')"
fi
public_host="${XEMA_PUBLIC_HOST:-}"
hostname="${XEMA_CERT_CN:-${public_host:-$(hostname -f)}}"
[[ "$ip" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]
[[ "$hostname" =~ ^[A-Za-z0-9][A-Za-z0-9.-]*$ ]]
cert=/etc/ssl/certs/certificate.pem
key=/etc/ssl/private/key.pem
certificate_matches() {
    openssl x509 -in "$cert" -noout -checkend 2592000 >/dev/null 2>&1 || return 1
    if [ -z "$public_host" ]; then
        openssl x509 -in "$cert" -noout -checkip "$ip" | grep -Fq ' does match certificate' || return 1
    fi
    openssl x509 -in "$cert" -noout -checkhost "$hostname" | grep -Fq ' does match certificate'
}
if [ ! -s "$cert" ] || [ ! -s "$key" ] || ! certificate_matches; then
    if [ -s "$cert" ] && [ "${XEMA_REGENERATE_SELF_SIGNED_TLS:-auto}" != 1 ]; then
        subject="$(openssl x509 -in "$cert" -noout -subject -nameopt RFC2253 | cut -d= -f2-)"
        issuer="$(openssl x509 -in "$cert" -noout -issuer -nameopt RFC2253 | cut -d= -f2-)"
        if [ "${XEMA_REGENERATE_SELF_SIGNED_TLS:-auto}" != auto ] || [ "$subject" != "$issuer" ]; then
            echo 'TLS certificate needs attention. Supply a matching trusted certificate; CA-issued certificates are never silently replaced.' >&2
            false
        fi
    fi
    mkdir -p /etc/ssl/private /etc/ssl/certs
    openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
        -keyout "$backup/new-key.pem" -out "$backup/new-cert.pem" \
        -subj "/CN=$hostname" -addext "subjectAltName=IP:$ip,DNS:$hostname,DNS:$(hostname -s)" \
        -addext 'basicConstraints=critical,CA:FALSE' \
        -addext 'keyUsage=critical,digitalSignature,keyEncipherment' \
        -addext 'extendedKeyUsage=serverAuth' >/dev/null 2>&1
    install -m 0600 "$backup/new-key.pem" "$key"
    install -m 0644 "$backup/new-cert.pem" "$cert"
    echo 'Generated a LAN certificate with current IP/hostname SANs. Clients still need explicit certificate trust.'
fi
certificate_matches
test "$(openssl x509 -in "$cert" -pubkey -noout | openssl sha256)" = \
     "$(openssl pkey -in "$key" -pubout | openssl sha256)"
mkdir -p /etc/nginx/snippets
install -m 0644 "$here/xema-proxy-security.conf" /etc/nginx/snippets/xema-proxy-security.conf
install -m 0644 "$here/xema-secure.nginx" "$site"
nginx -t
# Deployer can defer reload until the matching backend has started.
if [ "${XEMA_DEFER_NGINX_RELOAD:-0}" != 1 ]; then systemctl reload nginx; fi
echo "Web security configured. Backup: $backup"
