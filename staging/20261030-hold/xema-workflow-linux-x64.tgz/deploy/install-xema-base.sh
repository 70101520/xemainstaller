#!/usr/bin/env bash
set -euo pipefail
umask 077

[ "$(id -u)" -eq 0 ] || { echo 'Root required.' >&2; exit 1; }
. /etc/os-release
[ "$ID" = ubuntu ] && [ "$VERSION_ID" = 24.04 ] && [ "$(uname -m)" = x86_64 ] || {
  echo 'Fresh base installer currently qualifies only Ubuntu 24.04 AMD64.' >&2; exit 1;
}
package="$(realpath "${1:?Verified workflow package directory required}")"
script_dir="$(cd -- "$(dirname -- "$0")" && pwd)"
[ -s "$package/app/Manager.dll" ] || { echo 'Verified Manager payload missing.' >&2; exit 1; }
[ ! -e /var/lib/xema/manager/appsettings.json ] || { echo 'Fresh install refused on an existing site.' >&2; exit 1; }

python3 "$script_dir/configure-xema-base.py" preflight
python3 "$script_dir/configure-xema-base.py" backup
python3 "$script_dir/configure-xema-base.py" download

# Avoid exposing newly installed services with distribution/default credentials.
created_policy=0
restore_policy() {
  if [ "$created_policy" -eq 1 ]; then rm -f /usr/sbin/policy-rc.d; fi
}
trap restore_policy EXIT
if [ ! -e /usr/sbin/policy-rc.d ]; then
  printf '#!/bin/sh\nexit 101\n' >/usr/sbin/policy-rc.d
  chmod 0755 /usr/sbin/policy-rc.d
  created_policy=1
fi
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y ca-certificates curl unzip at sngrep libpcap0.8 asterisk asterisk-dev gcc libc6-dev nginx \
  rabbitmq-server redis-server prometheus mariadb-server sox libsox-fmt-all ufw \
  aspnetcore-runtime-10.0 python3-json5
restore_policy
created_policy=0

install -d -m 0750 /var/lib/xema/manager
cp -a "$package/app/." /var/lib/xema/manager/
chmod +x /var/lib/xema/manager/Manager
python3 "$script_dir/configure-xema-base.py" configure
systemctl daemon-reload
systemctl enable --now mariadb redis-server rabbitmq-server
python3 "$script_dir/configure-xema-base.py" accounts
XEMA_DEFER_NGINX_RELOAD=1 bash "$script_dir/apply-xema-runtime-prereqs.sh"
bash "$script_dir/install-xema-hold-module.sh"
systemctl enable --now asterisk nginx prometheus
echo 'Fresh base configured. Manager and auxiliary workers start only after workflow deployment/readiness.'
