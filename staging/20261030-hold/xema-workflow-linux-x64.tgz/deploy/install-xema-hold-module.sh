#!/usr/bin/env bash
set -Eeuo pipefail
[[ $(id -u) == 0 ]] || { echo 'Run as root.' >&2; exit 1; }
source_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
source_file="$source_dir/asterisk/res_xema_hold.c"
[[ -f "$source_file" && -f /usr/include/asterisk/manager.h ]] || {
    echo 'Native hold requires its source and matching asterisk-dev headers.' >&2; exit 1;
}
installed="$(dpkg-query -W -f='${Version}' asterisk)"
headers="$(dpkg-query -W -f='${Version}' asterisk-dev)"
[[ "$installed" == "$headers" ]] || { echo 'Asterisk runtime/header versions differ.' >&2; exit 1; }
build="$(mktemp -d /tmp/xema-hold-build.XXXXXX)"
trap 'rm -rf -- "$build"' EXIT
gcc -shared -fPIC -O2 -Wall -Wextra -Wno-unused-parameter -Werror -D_GNU_SOURCE \
    '-DAST_MODULE="res_xema_hold"' -DAST_MODULE_SELF_SYM=__internal_res_xema_hold_self \
    "$source_file" -o "$build/res_xema_hold.so"
if [[ ${1:-} == --build-only ]]; then
    install -m 0644 "$build/res_xema_hold.so" "${2:?Build destination required}"
    exit 0
fi
[[ $# == 0 ]] || { echo 'Unexpected installer argument.' >&2; exit 1; }
# Install this module only. No SIP, Queue, dialplan or service configuration changes.
module_dir="$(python3 - <<'PY'
import configparser
from pathlib import Path
import subprocess
config = configparser.ConfigParser(delimiters=('=>', '='), interpolation=None, strict=False)
config.read('/etc/asterisk/asterisk.conf')
directory = config.get('directories', 'astmoddir', fallback='').strip()
if not directory:
    candidates = [Path(p).parent for p in subprocess.check_output(
        ['dpkg-query', '-L', 'asterisk-modules'], text=True).splitlines() if p.endswith('/res_musiconhold.so')]
    if len(candidates) != 1:
        raise SystemExit('Could not determine the installed Asterisk module directory.')
    directory = str(candidates[0])
path = Path(directory)
if not path.is_absolute() or not path.is_dir():
    raise SystemExit('Configured Asterisk module directory is invalid or missing.')
print(path)
PY
)"
destination="$module_dir/res_xema_hold.so"
if [[ -e "$destination" ]]; then
    cmp -s "$build/res_xema_hold.so" "$destination" && exit 0
    echo 'A different native hold module is already installed; use a reviewed upgrade/rollback.' >&2
    exit 1
fi
install -m 0644 "$build/res_xema_hold.so" "$destination"
if systemctl is-active --quiet asterisk; then
    if ! asterisk -rx 'module load res_xema_hold.so' | grep -q 'Loaded res_xema_hold.so'; then
        echo 'Native hold load could not be confirmed. No service was restarted.' >&2
        exit 1
    fi
fi
sha256sum "$destination"
