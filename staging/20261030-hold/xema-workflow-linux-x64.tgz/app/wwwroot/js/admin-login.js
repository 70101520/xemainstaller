(() => {
    const form = document.getElementById('admin-login-form');
    const password = document.getElementById('Password');
    const toggle = document.querySelector('.password-toggle');
    const submit = form?.querySelector('.signin-submit');
    const label = submit?.querySelector('.submit-label');
    if (!form || !password || !toggle || !submit || !label) return;

    const hidePassword = () => {
        password.type = 'password';
        toggle.setAttribute('aria-pressed', 'false');
        toggle.setAttribute('aria-label', 'Show password');
        toggle.title = 'Show password';
        toggle.querySelector('.signin-icon').classList.remove('icon-eye-off');
        toggle.querySelector('.signin-icon').classList.add('icon-eye');
    };
    toggle.hidden = false;
    toggle.addEventListener('click', () => {
        if (password.type === 'text') { hidePassword(); return; }
        password.type = 'text';
        toggle.setAttribute('aria-pressed', 'true');
        toggle.setAttribute('aria-label', 'Hide password');
        toggle.title = 'Hide password';
        toggle.querySelector('.signin-icon').classList.replace('icon-eye', 'icon-eye-off');
    });
    form.addEventListener('submit', event => {
        if (submit.disabled) { event.preventDefault(); return; }
        hidePassword();
        submit.disabled = true;
        form.setAttribute('aria-busy', 'true');
        label.textContent = 'Signing in...';
    });
    // Browser Back can restore the submitted page from its cache.
    window.addEventListener('pageshow', () => {
        hidePassword();
        submit.disabled = false;
        form.removeAttribute('aria-busy');
        label.textContent = 'Sign in';
    });
})();
